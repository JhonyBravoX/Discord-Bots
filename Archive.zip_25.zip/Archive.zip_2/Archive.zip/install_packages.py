import subprocess

subprocess.call(['pip', 'install', '-r', 'requirements.txt'])
