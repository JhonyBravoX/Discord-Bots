const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

const commandPrefix = '!post';

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.content.startsWith(commandPrefix)) return;

  // Remove the command prefix from the message
  const messageContent = message.content.slice(commandPrefix.length).trim();
  const [command, ...args] = messageContent.split(' ');

  if (command === 'reply') {
    const [destinationChannelId, messageId, ...replyText] = args;
    const fetchedMessage = await client.channels.cache.get(destinationChannelId).messages.fetch(messageId).catch(console.error);

    if (fetchedMessage) {
      await fetchedMessage.reply(replyText.join(' '));
    } else {
      message.channel.send('Message not found. Please provide a valid channel ID and message ID.');
    }
    return;
  }

  const [channelIds, ...messageText] = messageContent.split(' ');

  // Split channel IDs by comma and filter out empty strings
  const channelIdsArray = channelIds.split(',').filter(Boolean);

  // Check if the message contains any URLs
  const regex = /(https?:\/\/[^\s]+)/g;
  const urls = messageText.join(' ').match(regex) || [];

  // Prepare media attachments
  const mediaAttachments = [];
  if (message.attachments && message.attachments.size > 0) {
    mediaAttachments.push(...message.attachments.map((attachment) => attachment.url));
  }

  // Iterate over each channel ID and send the message
  for (const channelId of channelIdsArray) {
    // Check if there are any URLs in the message
    if (urls.length === 0) {
      // If there are no URLs, send the message without buttons and media attachments
      const channel = client.channels.cache.get(channelId);
      if (channel) {
        await channel.send({
          content: messageText.join(' '),
          files: mediaAttachments,
        });
      } else {
        console.error(`Channel with ID ${channelId} not found.`);
      }
    } else {
      // Replace URLs with buttons
      const contentWithoutUrls = messageText.join(' ').replace(regex, '');
      const buttons = urls.map((url) => {
        return {
          type: 2, // Button
          label: 'SOURCE',
          style: 5, // Link style
          url: url,
        };
      });

      // Send the message with buttons and media attachments to the specific channel
      const channel = client.channels.cache.get(channelId);
      if (channel) {
        await channel.send({
          content: contentWithoutUrls,
          components: [
            {
              type: 1, // Action Row
              components: buttons,
            },
          ],
          files: mediaAttachments,
        });
      } else {
        console.error(`Channel with ID ${channelId} not found.`);
      }
    }
  }
});

client.login('MTE2MDMxMTM2ODY2NzM3NzY5NA.Gsc3wF.9B0geGVBS-MtFWV0DLtgqyVqhcLElPFMsiFvyw');
